<?php

class Controller {

	function __construct() {
		// echo 'Main controller<br />';
		// $this->view = new View();
		$this->modal = new Model();
	}

}