<?php require 'views/header.php'; ?>

<hr />
<?php echo $this->msg; ?>