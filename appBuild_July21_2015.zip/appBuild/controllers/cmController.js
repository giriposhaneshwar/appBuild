(function () {
  // 'use strict'
  var app = angular.module('appBuild')

  var cmController = function ($scope, sTest, $http, serviceCall, $location) {
    // Check login
    if(window.localStorage['login'] != 'undefined') {
      $scope.getOn = window.localStorage['user']
    } else {
      $scope.getOn = ''
    }

    if($scope.getOn.length == 0) {
      console.log($scope.getOn)
      window.location.hash = '#/login'
    }
    // //// Login Check End

    $scope.msg = 'CM Page'

    // main controller page function
    $scope.page()

    // $scope.msg = $http.get(url)
    $scope.curNav = $location.path().substring(1)

    // Get List of Customers
    var url = 'customer/'
    var method = 'getList'
    var data = {action: method}

    var dt = serviceCall.getService(url, data, function (res) {
      $scope.msg = res
    })
  }

  // Defining the controller
  app.controller('cmController', cmController)
}())
