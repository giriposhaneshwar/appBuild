(function () {
  // 'use strict'
  var app = angular.module('appBuild')

  var dashboardController = function ($scope, sTest, $http, serviceCall, $location) {
    // Check login
    if(window.localStorage['login'] != 'undefined') {
      $scope.getOn = window.localStorage['user']
    } else {
      $scope.getOn = ''
    }

    if($scope.getOn == null) {
      console.log($scope.getOn)
      window.location.hash = '#/login'
    }
    // //// Login Check End

    // $scope.msg = "Page loaded successfully"
    $scope.msg = 'Dashboard Page'

    // Request the server
    var url = ''
    var obj = {}
    obj.method = 'dashboard/getStats'
    obj.data = ''

    var dt = serviceCall.getService(url, obj, function (data) {
      $scope.msg = data
    // console.log('data', data)
    })

    // main controller page function
    $scope.page()
  }

  // Defining the controller
  app.controller('dashboardController', dashboardController)
}())
