var appData = {
  customerFormVal: [],
  customers: [],
  products: []
}
