<?php 
/**
 * Login Model
 */
 class Dc_Model extends Model
 {
 	
 	function __construct()
 	{
        parent::__construct();

 		// echo "this is login model\n";
 	}

    // Login User 
 	function getStats($postData)
    {
        echo "Getting the stats of dashboard";        
    }


 } ?>