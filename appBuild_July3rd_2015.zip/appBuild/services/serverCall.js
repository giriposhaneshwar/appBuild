(function(){
	var app = angular.module("appBuild");

	app.factory("serviceCall", function($http){

		var urlPre = "http://localhost/dc/";


		return {
		        getService: function(url,data,cb){
                    if(!data){ data = {}; }

                    // var dtype = 'json';
                    /*if(type==='post'){
                        dtype = 'json';
                    }else{
                        dtype = 'html';
                    }*/

                    // console.log("type is ", type);
                    
                    var rtn = {};
                    var rtn1 = {};
		            /*$.ajax({
		                url: url,
		                type: 'post',
						data:data,
		                dataType: 'json',
		                async: false,
		                success: function (r) {
		                	// console.log("sr", r);
		                     if(cb){
		                     	// console.log("i am at callback", r);
	                                 cb(r);
	                             }else{
	                             	// console.log("i am not calling back ", r);
	                                 rtn = r;
	                             } 
		                }
		            });*/
					

					
		           /* rtn = $http.post(url, data).success(function(data, status, headers, config){
		            	console.log("Success", data, status, headers, config);
		            	rtn1 = data;
		            	return data;
		            }).error(function(data, status, headers, config){
		            	console.log("error", data, status, headers, config);
		            });

		            console.log("rtn", rtn);*/

		            rtn = $http({
						    url: urlPre+""+url,
						    method: "POST",
						    data: JSON.stringify(data)
						    }).success(function (data, status, headers, config) {

						    	if(cb){
						    		return cb(data);
						    	}else{
						    		return data;
						    	}
						        console.log(data, status, headers, config);
						        // return data;
						    }).error(function (data, status, headers, config) {});

		            // return rtn;
		        }    	

		}// return end

	});
}());