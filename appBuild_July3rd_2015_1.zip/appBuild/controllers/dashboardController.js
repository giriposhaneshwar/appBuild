(function(){
	// 'use strict';
	var app = angular.module("appBuild");

	var dashboardController = function($scope, sTest, $http, serviceCall, $location){
		
		// Check login
		if(window.localStorage['login'] != 'undefined'){
			$scope.getOn = window.localStorage['login'];
		}else{
			$scope.getOn = "";
		}

		if($scope.getOn.length == 0){
			console.log($scope.getOn);
			window.location.hash = "#/login";
		}else{
			window.location.hash = "#/dashboard";
		}

		// $scope.msg = "Page loaded successfully";
		var url = "http://localhost/appBuildServer"
		$scope.msg = "Dashboard Page";
		// $scope.msg = $http.get(url);
		
		/*$scope.curNav = $location.path().substring(1);
		console.log("page", $scope.curNav);	*/

		// main controller page function
		$scope.page();
	}


	// Defining the controller
	app.controller("dashboardController", dashboardController);
}());