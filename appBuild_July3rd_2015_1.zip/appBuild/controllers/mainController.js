(function(){
	// 'use strict';
	var app = angular.module("appBuild");

	var mainController = function($scope, sTest, $http, serviceCall, $location){
		// $scope.msg = "Page loaded successfully";
		var url = "http://localhost/appBuildServer";
		// $scope.msg = $http.get(url);

		// get preset page
			// console.log("$scope.webNav", $scope.webNav);
			// console.log("$scope.appNav", $scope.appNav);

		
		
		$scope.page = function(){
			

			var path = window.location.hash;
			$scope.linkLoc = path.substring(2);

			angular.forEach($scope.webNav, function(i, n){
				var link = path.substring(2);
				// console.log(i, n, path);
				if(link == i){
					$scope.inLoc = "web";				
				}
			});

			angular.forEach($scope.appNav, function(i, n){
				var link = path.substring(2);	
				// console.log(i, n, link);
				if(link == i){
					$scope.inLoc = "app";
					$scope.class = "active";				
				}
			});


			if($scope.inLoc == "web"){
				// console.log("I am at web side");
				$scope.path = 'out';				
			}else if($scope.inLoc == "app"){
				// console.log("This is application");
				$scope.path = 'in';
			}
		}


		// setting up the navigation menu
		// $scope.page();
	}


	// Defining the controller
	app.controller("mainController", mainController);
}());