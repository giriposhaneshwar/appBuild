(function(){
	// 'use strict';
	var app = angular.module("appBuild");

	var dcController = function($scope, sTest, $http, serviceCall, $location){
		// $scope.msg = "Page loaded successfully";
		var url = "http://localhost/appBuildServer";
		$scope.msg = "DC Form";

		// main controller page function
		$scope.page();

		// setting up the navigation menu
		$scope.curNav = $location.path().substring(1);
		// console.log("page", $scope.curNav);

		// $scope.msg = $http.get(url);
		// Product List Holder
		$scope.productList = [];

		$('.date').datetimepicker({
            "pickTime":false,
            "format" : "DD-MM-YYYY"
        });
        $('.date').data("DateTimePicker").setMinDate(new Date());

        // restricting to the numbres only
        // $scope.onlyNumbers = /^\d+$/;
        
		$scope.formSubmit = function(d, sData){
			d.preventDefault();

			console.log(sData);
 

			var obj = "";
			var url = "dcServer/dc/";

			var dt = serviceCall.getService(url, sData, function(data){
				$scope.msg = data;
				console.log("data", data);		
			});
		}

		$scope.addProductRow = function(evt, pData){
			evt.preventDefault();

			$scope.getSizeObject = Object.keys(pData).length;

			if($scope.getSizeObject == 4){
				$scope.productList.push(pData);
				$scope.product = {};		
			}else{
				angular.forEach($scope.product, function(a, b){
					console.log(a, a.length, b, b.length);
				});
			}
		}

		$scope.editRow = function(evt, key, val){
			evt.preventDefault();
			console.log(key, val);
		}

		$scope.delRow = function(evt, key, val){
			evt.preventDefault();
			
			var index = $scope.productList.indexOf(val);
			$scope.productList.splice(index, 1);
		}

		$scope.formCancel = function(evt, data){
			evt.preventDefault();
			// $scope.productList.splice();
		}
		// console.log($scope.productList);

	}


	// Defining the controller
	app.controller("dcController", dcController);
}());