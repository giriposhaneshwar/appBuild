(function(){
	// 'use strict';
	var app = angular.module("appBuild");

	var loginController = function($scope, sTest, $http, serviceCall, $location){
		

		// Check login
		$scope.getOn = window.localStorage['login'];
		// console.log($scope.getOn);

		if($scope.getOn != undefined){
			if($scope.getOn.length == 0){
				window.location.hash = "#/login";
			}else{
				console.log($scope.getOn);
				window.location.hash = "#/dashboard";
			}
		}else{
			console.log("scope is ", $scope.getOn);
		}


		// $scope.msg = "Page loaded successfully";
		var url = "http://localhost/dcServer"
		$scope.msg = "Login Page";
		// $scope.msg = $http.get(url);
		// window.location.hash = '/home';

		// main controller page function
		$scope.page();

		$scope.login = function(d, data){
			d.preventDefault();
			// console.log(d, data);

			var url = "dcServer/login/";

			var dt = serviceCall.getService(url, data, function(res){
				$scope.msg = res;
				console.log("data", res.result);

				if(res.result == 'false'){
					$scope.er = "false";
					$scope.resText = res.response;
				}else{
					$scope.er = "true";
					$scope.resText = "Logged In";
					window.localStorage['login'] = res.email;
					window.localStorage['user'] = res.personName;
					window.location.hash = "#/dashboard";

				}
			});

			// $scope.resText = "Trying to login";

		}
	}


	// Defining the controller
	app.controller("loginController", loginController);
}());