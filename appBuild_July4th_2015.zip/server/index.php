<?php
$jsonData = file_get_contents("php://input");

// echo "Data is : ".json_encode($jsonData);
// $data = json_decode($jsonData);

// $contents = utf8_encode($jsonData); 
// $results = json_decode($contents);



// $data = json_encode($contents);
// $data2 = json_decode($data, true);

$d = json_encode($jsonData);
$f = json_decode($d);

$df = gettype($f);


var_dump($df);


?>