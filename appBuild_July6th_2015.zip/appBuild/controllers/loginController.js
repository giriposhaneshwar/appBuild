(function(){
	// 'use strict';
	var app = angular.module("appBuild");

	var loginController = function($scope, sTest, $http, serviceCall, $location){
		

		// Check login
		$scope.getOn = window.localStorage['login'];
		// console.log($scope.getOn);

		if($scope.getOn != undefined){
			if($scope.getOn.length == 0){
				window.localStorage.removeItem('user');
				window.localStorage.removeItem('login');
				window.location.hash = "#/login";
			}else{
				if(window.localStorage['user'] == undefined && window.localStorage['login'] == undefined){
					window.localStorage.removeItem('user');
					window.localStorage.removeItem('login');					
				}
				console.log($scope.getOn);
				window.location.hash = "#/dashboard";
			}
		}else{
			console.log("scope is ", $scope.getOn);
		}


		// $scope.msg = "Page loaded successfully";
		$scope.msg = "Login Page";
		// $scope.msg = $http.get(url);
		// window.location.hash = '/home';

		// main controller page function
		$scope.page();

		$scope.login = function(d, data){
			d.preventDefault();
			// console.log(d, data);

			var url = "";
			var obj = {};
			obj.controller = "login";
			obj.method = "loginUser";
			obj.data = data;

			console.log("Sending Data", obj);

			var dt = serviceCall.getService(url, obj, function(res){
				$scope.msg = res;
				console.log("data", res);

				if(res.result == 'false'){
					$scope.er = "false";
					$scope.resText = res.response;
					window.location.hash = "#/login";
				}else{
					$scope.er = "true";
					$scope.resText = "Logged In";
					// window.localStorage['login'] = res.email;
					// window.localStorage['user'] = res.personName;
					// window.location.hash = "#/dashboard";

				}
			});

			// $scope.resText = "Trying to login";

		}
	}


	// Defining the controller
	app.controller("loginController", loginController);
}());