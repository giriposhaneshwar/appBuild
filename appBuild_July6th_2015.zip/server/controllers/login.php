<?php

class Login extends Controller {

	private $dbh = new Model();

	function __construct() {
		parent::__construct();

		
		// echo 'We are in login Controller';
	}

	// Loging the user to application
	function loginUser($data){
		// echo $data['username'];
	 	
	 	// $dbh = new Model();		 	
	 	foreach($this->dbh->query('SELECT * from user_accounts') as $row) {
	        print_r($row);
	    }
	    // $dbh = null;
	    
	    // echo "DB Set from login controller";
	}

}