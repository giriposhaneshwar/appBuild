<?php

class Model extends PDO {

	function __construct() {
		
		/// DB Connection
		$host = "localhost";
		$user = "root";
		$pass = "mysql";
		$db = "appBuild";
		/*try {
		    $dbh = new PDO('mysql:host='.$host.';dbname='.$db, $user, $pass);
		    foreach($dbh->query('SELECT * from user_accounts') as $row) {
		        print_r($row);
		    }
		    $dbh = null;
		    echo "DB Set";
		} catch (PDOException $e) {
		    print "Error!: " . $e->getMessage() . "<br/>";
		    die();
		}
*/


		/* Connect to an ODBC database using driver invocation */
		$dsn = 'mysql:dbname='.$db.';host='.$host;
		try {
		    $dbh = new PDO($dsn, $user, $pass);
		} catch (PDOException $e) {
		    echo 'Connection failed: ' . $e->getMessage();
		}

	}

}