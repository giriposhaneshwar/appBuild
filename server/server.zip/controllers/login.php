<?php

class Login extends Controller {

	function __construct() {
		parent::__construct();

		
		echo 'We are in login Controller';
	}

	// Loging the user to application
	function loginUser(){
		// echo $data['username'];

	    
	    echo "DB Set from login controller";
	}

	function loadModel(){
		echo $this->modal->run();
	}

}